<template>
  <div>
    <el-result title="404" sub-title="未匹配到任何结果"></el-result>
  </div>
</template>
<script setup name='NotFound' lang='ts'>
</script>
<style scoped>
   
</style>