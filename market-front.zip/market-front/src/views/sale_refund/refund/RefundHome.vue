<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<script setup name='RefundHome' lang='ts'>

</script>
<style scoped>

</style>