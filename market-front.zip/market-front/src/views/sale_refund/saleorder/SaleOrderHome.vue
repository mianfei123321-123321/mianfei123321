<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<script setup name='SaleOrderHome' lang='ts'>

</script>
<style scoped>

</style>