<template>
  <div>
    <router-view></router-view>
  </div>
</template>
<script setup name='AuditHome' lang='ts'>

</script>
<style scoped>

</style>
