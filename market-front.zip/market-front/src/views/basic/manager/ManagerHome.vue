<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<script setup name='ManagerHome' lang='ts'>

</script>
<style scoped>

</style>