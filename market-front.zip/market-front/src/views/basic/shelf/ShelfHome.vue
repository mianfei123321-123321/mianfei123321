<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<script setup name='ShelfHome' lang='ts'>

</script>
<style scoped>

</style>