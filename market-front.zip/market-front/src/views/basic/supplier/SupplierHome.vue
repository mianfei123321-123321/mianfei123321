<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<script setup name='SupplierHome' lang='ts'>

</script>
<style scoped>

</style>