<template>
  <div>
    <router-view></router-view>
  </div>
</template>
<script setup name='StatisticsHome' lang='ts'>

</script>
<style scoped>

</style>
