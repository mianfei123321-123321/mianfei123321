<template>
  <div>
    <router-view></router-view>
  </div>
</template>
<script setup name='Warehouse' lang='ts'>

</script>
<style scoped>

</style>
