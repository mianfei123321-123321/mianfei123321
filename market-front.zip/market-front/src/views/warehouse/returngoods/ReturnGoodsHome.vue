<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<script setup name='ReturnGoodsHome' lang='ts'>

</script>
<style scoped>

</style>