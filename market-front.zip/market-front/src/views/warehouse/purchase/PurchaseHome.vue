<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<script setup name='PurchaseHome' lang='ts'>

</script>
<style scoped>

</style>