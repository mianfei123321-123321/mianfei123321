package com.roadjava.market.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.roadjava.market.bean.entity.ManagerDO;

/**
 * @author 乐之者java
 * @see <a href="http://www.roadjava.com">乐之者java</a>
 */
public interface ManagerMapper extends BaseMapper<ManagerDO> {
}
